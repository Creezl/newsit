<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<link rel="stylesheet" href="../site/stily.css">
    <title>Наша группа И-20-1</title>
</head>
<body>
 
<table
border="1"
align="center"
rules="rows"
style="width:60%;">


<table
border="1"
background="../img/fon1.jpg"
cellpadding="10"
style="width:100%; border-radius:5px;">

<tr>
<th>
<h1><font color="white">Наша группа И-20-1</font></h1>
</th>
</tr>

<table class=sb>
<!--САЙТБАР-->
<td   >
<center>
<h3 class=ss>Меню</h3>
<h4>
<a href="/ " style="text-decoration: none;">
<span class=ss>Главная &nbsp  &nbsp</span></a>

<a href="/speciality" style="text-decoration: none;">
<span class=ss>Специальности &nbsp  &nbsp</span;></a>

<a href="/contact" style="text-decoration: none;">
<span class=ss>Контакты  &nbsp  &nbsp</span></a>

<a href="/idv" style="text-decoration: none;">
<span class=ss>И-20-1 &nbsp  &nbsp</span;></a>

</h4>
</td>
</tr>
</table>
 </center>
 
<div>
<center><h2>Наша группа на паре "Web-программирование"</h2>
<img width=340px src= ../img/s4.jpg>
<p>Написание кода на языке JS</p></br>
<img width=500px src= ../img/s1.jpg>
<p>Запись кода в тетрадь</p></center></br>


<h3>Одногруппник Вася в библиотеке</h3>
<img width=340px src= ../img/s3.jpg>
<p>Взял книгу "Python"</p></br>


<h3>Никита усердно трудится над заданием преподавателя</h3>
<img width=300px src= ../img/s5.jpg></br></br>
<center><h3>Пары закончились можно и домой!</h3>
<img width=340px src= ../img/s2.jpg></br></br>

<h2>Расписание на понедельник</h2>
<ol>
 <li>Основы проектирования БД</li>
 <li>Методы и средства проектирования ИС</li>
 <li>Методы и средства проектирования ИС</li></center>
</ol> 
</div>
<table
border="1"
bgcolor="#cecece"
height="100"
cellpadding="10"
style="width:100%; border-radius:5px;">
<tr>
<th>
    <p style="text-indent:20px">Телефон +79501257140</p>
    <p style="text-indent:20px">Адрес электронной почты: creezl15@gmail.com</p>
</th>
</tr>
</table>
</td>
</tr>
</table>
</div>
</body>
</html><?php /**PATH /var/www/html/laravelapp/resources/views/idv.blade.php ENDPATH**/ ?>