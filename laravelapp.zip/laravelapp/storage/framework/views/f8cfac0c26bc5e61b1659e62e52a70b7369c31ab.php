<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<link rel="stylesheet" href="../site/stily.css">
    <title>Специальности АПТ</title>
</head>
<body>
 
<table
border="1"
align="center"
rules="rows"
style="width:60%;">
<table
border="1"
background="../img/fon1.jpg"
cellpadding="10"
style="width:100%; border-radius:5px;">

<tr><th>
<h1><font color="white">Специальности АПТ</font></h1>
</th></tr>

<table class=sb>
<!--САЙТБАР-->
<td   >
<center>
<h3 class=ss>Меню</h3>
<h4>
<a href="/ " style="text-decoration: none;">
<span class=ss>Главная &nbsp  &nbsp</span></a>

<a href="/speciality" style="text-decoration: none;">
<span class=ss>Специальности &nbsp  &nbsp</span;></a>

<a href="/contact" style="text-decoration: none;">
<span class=ss>Контакты  &nbsp  &nbsp</span></a>

<a href="/idv" style="text-decoration: none;">
<span class=ss>И-20-1 &nbsp  &nbsp</span;></a>

</h4>
</td>
</tr>
</table>
 </center>


<table
border="1"
bgcolor="#94c1f7"
cellpadding="10"
style="width:100%; border-radius:5px;">
<tr>
<td
rowspan="2"
style="width:80%">
<div class="container">
<div class="row">
  <div class="col-12">
    <h1>13.02.11 Техническая эксплуатация и обслуживание электрического и электромеханического оборудования (по отраслям)</h1>
  </div>
</div>
</div>
<div class="container">
<div class="row">
  <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
    <p style="text-indent:20px">Квалификация: техник Форма обучения: очная Нормативный срок освоения: 
        3 года 10 мес. На базе основного общего образования (очная форма)</p>
        
        <p style="text-indent:20px">на бюджетной основе Профиль получаемого профессионального образования: 
            технический Выпускник техникума профессионально готов к деятельности:</p>
        <p style="text-indent:20px">1.Организация технического обслуживания и ремонта электрического и электромеханического оборудования.</p>
        <p style="text-indent:20px">2.Выполнение сервисного обслуживания бытовых машин и приборов.</p>
        <p style="text-indent:20px">3.Организация деятельности производственного подразделения</p>
        <p style="text-indent:20px">4.Выполнение работ по рабочей профессии «Слесарь по ремонту электрооборудования».</p>
  </div>
  <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
    <img src="../img/sp1.jpg" width="80%">
  </div>
</div>
</div>

<div class="container">
    <div class="row">
      <div class="col-12">
        <h1>15.02.12 Монтаж, техническое обслуживание и ремонт промышленного оборудования (по отраслям)</h1>
      </div>
    </div>
    </div>
    <div class="container">
    <div class="row">
      <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
        <p style="text-indent:20px">Квалификация: техник-механик Форма обучения: очная Нормативный срок освоения: 
            3 года 10 мес. На базе основного общего образовання (очная форма) на бюджетной основе</p>
            
            <p style="text-indent:20px">Профиль получаемого профессионального образования: 
                технический Выпускник техникума профессионально готов к деятельности по видам деятельности:</p>
            <p style="text-indent:20px">1. Организация и проведение монтажа промышленного оборудования.</p>
            <p style="text-indent:20px">2. Организация и выполнение работ по эксплуатации промышленного оборудования.</p>
            <p style="text-indent:20px">3. Участие в организации производственной деятельности структурного подразделения.</p>
            <p style="text-indent:20px">4. Выполнение работ по рабочей профессии «Слесарь- ремонтник».</p>
      </div> 
      <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
        <img src="../img/sp2.jpg" width="80%">
      </div>     
    </div>
    </div>

    <div class="container">
        <div class="row">
          <div class="col-12">
            <h1>09.02.07 «Информационные системы и программирование»</h1>
          </div>
        </div>
        </div>
        <div class="container">
        <div class="row">
          <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
            <p style="text-indent:20px">Квалификация: специалист по информационным системам Форма обучения: очная</p>
                
                <p style="text-indent:20px">Нормативный срок освоения: 3 года 10 мес.</p>
                <p style="text-indent:20px">На базе основного общего образования (очная форма) на бюджетной основе</p>
                <p style="text-indent:20px">Профиль получаемого профессионального образования: технический Выпускник 
                    техникума профессионально готов к деятельности по видам деятельности:</p>
                <p style="text-indent:20px">1. Осуществление интеграции программных модулей.</p>
                <p style="text-indent:20px">2. Ревьюирование программных продуктов.</p>
                <p style="text-indent:20px">3. Проектирование, разработка и сопровождение информационных систем.</p>
                <p style="text-indent:20px">4. Соадминистрирование баз данных и серверов. Выполнение работ 
                    по рабочей профессии «Оператор электронно-вычислительных и вычислительных машин»</p>
          </div> 
          <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
            <img src="../img/sp3.jpg" width="80%">
          </div>      
        </div>
        </div>

        <div class="container">
            <div class="row">
              <div class="col-12">
                <h1>18.02.09 Переработка нефти и газа</h1>
              </div>
            </div>
            </div>
            <div class="container">
            <div class="row">
              <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                <p style="text-indent:20px">Квалификация: техник-технолог Форма обучения: очная, заочная Нормативный срок 
                    освоения: 3 года 10 мес. на бюджетной основе</p>
                    
                    <p style="text-indent:20px">На базе основного общего образования (очная форма) на внебюджетной основе</p>
                    <p style="text-indent:20px">На базе среднего общего образования (заочная форма) Профиль получаемого профессионального 
                        образования: естественнонаучный Выпускник техникума профессионально готов к деятельности по видам деятельности:</p>
                    <p style="text-indent:20px">1. Эксплуатация технологического оборудования и коммуникаций.</p>
                    <p style="text-indent:20px">2. Ведение технологического процесса на установках I и II категорий.</p>
                    <p style="text-indent:20px">3. Предупреждение и устранение возникающих производственных инцидентов.</p>
                    <p style="text-indent:20px">4. Организация работы коллектива подразделения.</p>                    
              </div> 
              <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                <img src="../img/sp4.jpg" width="80%">
              </div>      
            </div>
            </div>

            <div class="container">
                <div class="row">
                  <div class="col-12">
                    <h1>38.02.01 Экономика и бухгалтерский учет (по отраслям)</h1>
                  </div>
                </div>
                </div>
                <div class="container">
                <div class="row">
                  <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                    <p style="text-indent:20px">Квалификация: бухгалтер Форма обучения: очная Нормативный срок освоения: 2год 10 мес. На базе основного общего образования (очная форма)
                        на бюджетной основе</p>
                        
                        <p style="text-indent:20px">Профиль получаемого професснонального образования: социально-экономический Выпускник техникума профессионально готов к деятельности:</p>
                        <p style="text-indent:20px">1. Документирование хозяйственных операций и ведение бухгалтерского учета имущества организации.</p>
                        <p style="text-indent:20px">2. Ведение бухгалтерского учета источников формирования имущества, выполнение работ по инвентаризации имущества и финансовых обязательств организации.</p>
                        <p style="text-indent:20px">3. Проведение расчетов с бюджетом и внебюджетными фондами.
                            Выполнение работ по рабочей профессии «Кассир»</p>                                        
                  </div> 
                  <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
                    <img src="../img/sp5.jpg" width="80%">
                  </div>      
                </div>
                </div>
    <p><img src="../img/tab.PNG" align="center" width="120%"></p>
            
</td>



<!--низ страницы-->
<table
border="1"
bgcolor="#cecece"
height="100"
cellpadding="10"
style="width:100%; border-radius:5px;">
<tr>
<th>
    <p style="text-indent:20px">Телефон +79501257140</p>
    <p style="text-indent:20px">Адрес электронной почты: creezl15@gmail.com</p>
</th>
</tr>
</table>
</td>
</tr>
</table>
</div>
</body>
</html><?php /**PATH /var/www/html/laravelapp/resources/views/speciality.blade.php ENDPATH**/ ?>