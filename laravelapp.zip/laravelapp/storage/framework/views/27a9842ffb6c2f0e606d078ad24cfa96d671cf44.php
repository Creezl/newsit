﻿<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<link rel="stylesheet" href="../site/stily.css">
    <title>Контакты АПТ</title>
</head>
<body>
 
<table
border="1"
align="center"
rules="rows"
style="width:60%;">


<table
border="1"
background="../img/fon1.jpg"
cellpadding="10"
style="width:100%; border-radius:5px;">

<tr>
<th>
<h1><font color="white">Контакты АПТ</font></h1>
</th>
</tr>

<table class=sb>
<!--САЙТБАР-->
<td   >
<center>
<h3 class=ss>Меню</h3>
<h4>
<a href="/ " style="text-decoration: none;">
<span class=ss>Главная &nbsp  &nbsp</span></a>

<a href="/speciality" style="text-decoration: none;">
<span class=ss>Специальности &nbsp  &nbsp</span;></a>

<a href="/contact" style="text-decoration: none;">
<span class=ss>Контакты  &nbsp  &nbsp</span></a>

<a href="/idv" style="text-decoration: none;">
<span class=ss>И-20-1 &nbsp  &nbsp</span;></a>

</h4>
</td>
</tr>
</table>
 </center>

<table
border="1"
bgcolor="#B0C4DE"
cellpadding="10"
style="width:100%; border-radius:5px;">
<tr>
<td
rowspan="2"
style="width:80%">
<div class="container">
<div class="row">
  <div class="col-12">
    <h1>Контакты АПТ</h1>
  </div>
</div>
</div>
<div class="container">
<div class="row">
  <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
        <p style="text-indent:19px"><img src="../img/tele.png" width="4%"> <span style="margin-left:5px;">Телефон приемной комиссии: (3955) 51-21-04</span></p>        
        <p style="text-indent:19px"><img src="../img/tele.png" width="4%"> <span style="margin-left:5px;">Телефон\факс секретаря: (3955) 52-20-60</span></p>
        <p style="text-indent:17px"><img src="../img/poch.png" width="4%"> <span style="margin-left:5px;">Адрес электронной почты: apt@aptangarsk.ru</span></p>
        <p style="text-indent:20px"><a href="https://vk.com/aptangarsk?ysclid=lb29skog9n421026141"><img src="../img/vvk.png" width="10%"></a> </p>
        <p style="text-indent:20px">Официальный сайт техникума: <a class=ad href="http://www.aptangarsk.ru/">http://www.aptangarsk.ru/</a> </p>
        <p style="text-indent:20px"><h2>Места осуществления образовательной деятельности:</h2></p>
        <a href="https://yandex.ru/maps/11256/angarsk/house/52_y_kvartal_1/ZUkFaA9oTEMBXkJvYWJ0dHxiZAs=/?ll=103.886102%2C52.550019&z=19"><p style="text-indent:18px"><img src="../img/adr.png" width="3%"> <span class=ad>665830, Иркутская область, город Ангарск, 52 квартал, дом 1;</span></p>
        <p style="text-indent:18px"><img src="../img/adr.png" width="3%"> <span class=ad >665830, Иркутская область, город Ангарск, 52 квартал, дом 1/1;</span></p>
        <p style="text-indent:18px"><img src="../img/adr.png" width="3%"> <span class=ad >665830, Иркутская область, город Ангарск, 52 квартал, дом 1/4;</span></p></a>
  </div>
  <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
    <a href="http://www.aptangarsk.ru/"><img src="../img/log.png" width="60%"></a>
  </div>
</div>
</div>

<div class="container">
    <div class="row">
      <div class="col-12">
        <h1>Контакты студента</h1>
      </div>
    </div>
    </div>
    <div class="container">
    <div class="row">
      <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
            <p style="text-indent:19px"><img src="../img/tele.png" width="4%"> <span style="margin-left:10px;">Телефон: +79501257140</span></p>
 	    <a class=ad href="https://t.me/creezl"  text-decoration:none"><p style="text-indent:9px"><img src="../img/teleg.png" width="7%"> <span style="margin-left:0px;">Telegram: @creezl</span></p></a>
            <p style="text-indent:17px"><img src="../img/poch.png" width="4%"> <span style="margin-left:8px;">Адрес электронной почты: creezl15@gmail.com</span> </p>
            <p style="text-indent:18px"><img src="../img/adr.png" width="4%"> <span style="margin-left:6px;">Адрес: улица Толбухина, 46А, Усолье-Сибирское, Иркутская область, 665463;</span></p>
            
      </div>
      <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
        <a href="https://vk.com/creezl1"><img src="../img/ava.jpg" width="30%"></a>
      </div>
    </div>
    </div>
</td>


<!--низ страницы-->
<table
border="1"
bgcolor="#cecece"
height="100"
cellpadding="10"
style="width:100%; border-radius:5px;">
<tr>
<th>
    <p style="text-indent:20px">Телефон +79501257140</p>
    <p style="text-indent:20px">Адрес электронной почты: creezl15@gmail.com</p>
</th>
</tr>
</table>
</td>
</tr>
</table>
</div>
</body>
</html>
<?php /**PATH /var/www/html/laravelapp/resources/views/contact.blade.php ENDPATH**/ ?>